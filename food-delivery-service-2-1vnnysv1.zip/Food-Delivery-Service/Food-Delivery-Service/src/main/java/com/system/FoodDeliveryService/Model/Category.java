package com.system.FoodDeliveryService.Model;

public enum Category {
    cafes,
    clubs,
    AsianFoods,
    FamilyRestaurant,
}
