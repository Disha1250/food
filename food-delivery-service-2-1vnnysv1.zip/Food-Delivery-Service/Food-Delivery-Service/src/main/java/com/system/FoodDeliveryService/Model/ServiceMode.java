package com.system.FoodDeliveryService.Model;

public enum ServiceMode {
    membership_subscription,
    pay_on_demand
}
