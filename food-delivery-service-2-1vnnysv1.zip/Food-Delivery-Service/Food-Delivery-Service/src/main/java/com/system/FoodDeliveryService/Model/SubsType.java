package com.system.FoodDeliveryService.Model;

public enum SubsType {
    monthly,
    annually,
    notDefined
}
